#ifndef Caisse_H
#define Caisse_H

int MENU_CAISSE();

#endif
