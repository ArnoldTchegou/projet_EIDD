#ifndef Gerant_H
#define Gerant_H

void charge_new();
int MENU_GERANT();
void ecraser();
int nb_ligne();
char* copy_fich_tab();
void tab_prod();
size_t nb_ticket();

#endif
