#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stddef.h>
#include<assert.h>
#include<time.h>
#include"gerant.h"

//declaration des varaibles globales

//variables de choix d'options de menu(s) du programme
char choix1[2];
char choix2[2];
char choix3[2];
char choix4[2];
//variables de navigation entre les menus du programme
int stop1;
int stop2;
int stop3;
int stop4;
int stop5;

//tampon pour modifier le nom d'un produit
char nouveau_nom[64];

//ID stock l'id du produit en char grace à la fonction lire() et id pour le convertit en int
char ID[10];
int id;
//PU et ST stockent respectivement le prix unitaire et le stock en char grace à la fonction lire()
char PU[10];
char ST[10];

//tableau contenant les caractères autorisés pour le nom d'un produit
char alphabet[] = "abcdefghijklmnopqrstuvwxyz ";

//Structure produit
typedef struct{
	char nom[64];
	double prix_unit;
	double stocks;
}produit;

//Fonction qui permet de vider le tampon sur l'entrée standard
void vidertampon(){
	int c = 0;
	while(c !='\n' && c != EOF){
		c = getchar();
	}
}

//FONCTION DE LECTURE DE LA CHAINE PASSEE sur l'entrée standard STDIN
int lire(char* chaine, int taille){
	//chaine = malloc(taille*sizeof(char));
	char* positionEntree = NULL;
	//printf("%ld\n", sizeof(chaine));
	//on lit le texte au clavier et on verifie s'il y'a pas d'erreur
	if (fgets(chaine, taille*sizeof(char), stdin)!=NULL){
	//on recherche l'entrée avec strchr
		positionEntree = strchr(chaine,'\n');
		//si on trouve le retour à la ligne
		if (positionEntree != NULL){
		//on le remplace par \0
			*positionEntree = '\0';
		}
		else{
		//si la chaine est trop long on vide le buffer
			vidertampon();
		}
		return 1;
	}
	else{
	//s'il y'a eu une erreur on vide le buffer
		vidertampon();
		return 0;
	}
}

//fonction pour convertir une chaine de caratère en lettre minuscules

void transform (char* t){
	int i = 0;
	while(t[i]!='\0'){
		if('A'<=t[i] && t[i]<='Z'){
			t[i] = t[i] - 'A' + 'a';
		}
		else if(t[i] == ' '){
			t[i] = ' ';
		}
		i++;
	}
}

//fonction qui verifie l'orthographe sur le nom du nouveau produit

int inalphabet(char* t){
	transform (t);
	int i = 0;
	while(t[i]!='\0'){
		int j = 0;
		while((alphabet[j]!='\0')&&(t[i]!=alphabet[j])){
			j++;
		}
		if(alphabet[j]=='\0'){
			return 0;
		}
		i++;
	}
	return 1;
}


//charger un nouveau produit dans le stock
void ajouter(produit* prod, int n, char* stocks){
	FILE* f = fopen(stocks, "a");
	fwrite(prod, sizeof(produit), n, f);
	fclose(f);
}

//ecraser le fichier stock (modification du fichier)
void ecraser(produit* prod, int n, char* stocks){
	FILE* f = fopen(stocks, "w");
	fwrite(prod, sizeof(produit), n, f);
	fclose(f);
}

//nombre de ligne du fichier stock
int nb_ligne(char* stocks){
	FILE* f = fopen(stocks, "r");
	fseek(f, 0 , SEEK_END);
	int a = ftell(f)/sizeof(produit);
	rewind(f);
	fclose(f);
	return a;
}

//charger le fichier stock dans un tableau dynamique de structure produit
void charge_new(produit* prod, char* stocks){
	FILE* f = fopen(stocks, "r");
	//printf("%d\n",nb_ligne(stocks));
	fread(prod, sizeof(produit), nb_ligne(stocks), f);
	fclose(f);
}

//fonction qui retourne le nombre de produits disponibles en stock
int produit_dispo(produit* prod, char* stocks){
	int prod_dispo = nb_ligne(stocks);
	for(int i=0; i<nb_ligne(stocks); i++){
		if(prod[i].stocks == 0.0){
			prod_dispo--;	
		}
	}
	return prod_dispo;
}

//afficher la liste de produits dans le stock
void print_stocks(produit* new_prod, char* stocks){
	stop1 = 0;
	while(stop1!=1){
		printf("\t------------------------------------%d PRODUIT(S) EN MAGASIN-----------------------------------\n", produit_dispo(new_prod, stocks));
		
		printf("\n");
		
		for (int i=0; i<nb_ligne(stocks); i++){
			printf("\tid %d : \t\t%s  \t\tPrix_unitaire : %.2lf \t\t\tstocks : %.2lf\n",i+1,new_prod[i].nom, new_prod[i].prix_unit, new_prod[i].stocks);
		}
		printf("\t-----------------------------------------------------------------------------------------------\n");
		printf("\n\n");
		printf("\t\tEntrez 1 pour revenir au menu precedent\n");
		lire(choix1, 2);
		if (strcmp(choix1, "1")==0){
			printf("\e[1;1H\e[2J");
			stop1 = 1;
		}
		else{
			printf("\e[1;1H\e[2J");
			stop1 = 0;
		}
	}
}

//modifier un produit
void modifier_prod(produit* prod, char* stocks){
	stop5 =0;
	printf("\t---------------------------------Vous etes dans le menu MODIFIER UN NOUVEAU PRODUIT---------------------------\n");
	printf("\t\tDonner l'identifiant du produit:\n");
	while(stop5 !=1){
		lire(ID, 10);
		id = atoi(ID);
		//on se rassure que le produit est bien en stock
		if((id>0)&&(id<=nb_ligne(stocks))){
			//on affiche le nom du produit, son PU et le stock dispônible
			printf("\e[1;1H\e[2J");
			printf("\t\t%s  \tprix_unit: %.2lf \tstocks: %.2lf\n\n", prod[id-1].nom, prod[id-1].prix_unit, prod[id-1].stocks);
			stop1 = 0;
			while(stop1!=1){
				printf("\t\t1-) Entrez 1 pour modifier le nom\n");
				printf("\t\t2-) Entrez 2 pour modifier le prix unitaire\n");
				printf("\t\t3-) Entrez 3 pour modifier le stock\n");
				printf("\t\t4-) Entrez 4 pour afficher la liste de produits en stock\n");
				printf("\t\t5-) Entrez 5 pour revenir au menu principal\n");
				lire(choix1, 2);
				if (strcmp(choix1, "1")==0){
					printf("\e[1;1H\e[2J");
			printf("\t\t%s  \tprix_unit: %.2lf \tstocks: %.2lf\n\n", prod[id-1].nom, prod[id-1].prix_unit, prod[id-1].stocks);
					printf("\t\tModifier le nom du produit:\n");
					lire(nouveau_nom, 64);
					while(inalphabet(nouveau_nom)!=1){
						printf("\e[1;1H\e[2J");
			printf("\t\t%s  \tprix_unit: %.2lf \tstocks: %.2lf\n\n", prod[id-1].nom, prod[id-1].prix_unit, prod[id-1].stocks);
						printf("\t\tModifier le nom du produit:\n");
						lire(nouveau_nom, 64);
					}
					stop2 = 0;
					while(stop2!=1){
						printf("\t\t1-) Entrez 1 pour Enregistrer\n");
						printf("\t\t2-) Entrez 2 pour annuler\n");
						lire(choix2, 2);
						if (strcmp(choix2, "1")==0){
							strcpy(prod[id-1].nom, nouveau_nom);
							ecraser(prod, nb_ligne(stocks), "stocks");
							stop2 = 1;
							stop1 = 0;
							printf("\e[1;1H\e[2J");
						}
						else if (strcmp(choix2, "2")==0){
							printf("\e[1;1H\e[2J");
							stop2 = 1;
							stop1 = 0;
						}
						else{
							printf("\e[1;1H\e[2J");
							stop2 = 0;
						}
					}
				}
				else if (strcmp(choix1, "2")==0){
					printf("\e[1;1H\e[2J");
			printf("\t\t%s  \tprix_unit: %.2lf \tstocks: %.2lf\n\n", prod[id-1].nom, prod[id-1].prix_unit, prod[id-1].stocks);
					printf("\t\tModifiez le prix unitaire du produit:\n");
					lire(PU, 10);
					while(atof(PU)<=0){
						printf("\e[1;1H\e[2J");
			printf("\t\t%s  \tprix_unit: %.2lf \tstocks: %.2lf\n\n", prod[id-1].nom, prod[id-1].prix_unit, prod[id-1].stocks);
						printf("\t\tModifiez le prix unitaire du produit:\n");
						lire(PU, 10);
					}
					stop3 = 0;
					while(stop3 != 1){
						printf("\t\t1-) Entrez 1 pour Enregistrer\n");
						printf("\t\t2-) Entrez 2 pour annuler\n");
						lire(choix3, 2);
						if (strcmp(choix3, "1")==0){
							prod[id-1].prix_unit = atof(PU);
							ecraser(prod, nb_ligne(stocks), "stocks");
							stop3 = 1;
							stop1 = 0;
							printf("\e[1;1H\e[2J");
						}
						else if (strcmp(choix3, "2")==0){
							printf("\e[1;1H\e[2J");
							stop3 = 1;
							stop1 = 0;
						}
						else{
							printf("\e[1;1H\e[2J");
							stop3 = 0;
						}
					}
				}
				else if (strcmp(choix1, "3")==0){
					printf("\e[1;1H\e[2J");
			printf("\t\t%s  \tprix_unit: %.2lf \tstocks: %.2lf\n\n", prod[id-1].nom, prod[id-1].prix_unit, prod[id-1].stocks);
					printf("\t\tModifiez le stocks du produit:\n");
					lire(ST, 10);
					while(atof(ST)<=0){
						printf("\e[1;1H\e[2J");
			printf("\t\t%s  \tprix_unit: %.2lf \tstocks: %.2lf\n\n", prod[id-1].nom, prod[id-1].prix_unit, prod[id-1].stocks);
						printf("\t\tModifiez le stocks du produit:\n");
						lire(ST, 10);
					}
					stop4 = 0;
					while(stop4 != 1){
						printf("\t\t1-) Entrez 1 pour Enregistrer\n");
						printf("\t\t2-) Entrez 2 pour annuler\n");
						lire(choix4, 2);
						if (strcmp(choix4, "1")==0){
							prod[id-1].stocks = atof(ST);
							ecraser(prod, nb_ligne(stocks), "stocks");
							stop4 = 1;
							stop1 = 0;
							printf("\e[1;1H\e[2J");
						}
						else if (strcmp(choix4, "2")==0){
							printf("\e[1;1H\e[2J");
							stop4 = 1;
							stop1 = 0;
						}
						else{
							printf("\e[1;1H\e[2J");
							stop4 = 0;
						}
					}
				}
				else if (strcmp(choix1, "4")==0){
					printf("\e[1;1H\e[2J");
					print_stocks(prod, stocks);
					printf("\n\n");
					stop1 = 0;
				}
				else if (strcmp(choix1, "5")==0){
					printf("\e[1;1H\e[2J");
					stop1 = 1;
				}
				else{
					printf("\e[1;1H\e[2J");
					stop1 = 0;
				}
			}
			stop5 =1;
		}
		//si le produit n'est pas dans le stock on ne quitte pas le programme
		else{
			printf("\e[1;1H\e[2J");
			printf("\t\tle produit dont l'identifiant est : %d nexiste pas en stock\n", id);
			printf("\n");
			printf("\t\tEntrez un identifiant valide:\n");
			stop5 =0;	
		}
	}
}

//supprimer un produit du fichier stock
void supprimer_prod(produit* prod, char* stocks){
	stop1 = 0;
	while(stop1!=1){
	printf("\t---------------------------------Vous etes dans le menu SUPPRIMER UN NOUVEAU PRODUIT---------------------------\n");
		printf("\t\t1-) Entrez 1 pour supprimer un produit\n");
		printf("\t\t2-) Entrez 2 pour afficher la liste de produits\n");
		printf("\t\t3-) Entrez 3 pour revenir au menu principal\n");
		lire(choix1, 2);
		if (strcmp(choix1, "1")==0){
			printf("\e[1;1H\e[2J");
			printf("\t\tDonnez l'identifiant du produit à supprimer\n");
			//on se rassure que le produit est bien dans le stock
			stop3 = 0;
			while(stop3 !=1){
				lire(ID, 10);
				id = atoi(ID);
				if((id>0)&&(id<=nb_ligne(stocks))){
			printf("\t\t%s  \tprix_unit: %.2lf \tstocks: %.2lf\n\n", prod[id-1].nom, prod[id-1].prix_unit, prod[id-1].stocks);
					stop2 = 0;
					while(stop2 != 1){
						printf("\t\t1-) Entrez 1 pour valider la suppression du produit\n");
						printf("\t\t2-) Entrez 2 pour annuler\n");
						lire(choix2, 2);
						if(strcmp(choix2, "1")==0){
							strcpy(prod[id-1].nom, ""); 
							prod[id-1].prix_unit = 0.0;
							prod[id-1].stocks = 0.0;			
							ecraser(prod, nb_ligne(stocks), "stocks");
							stop2 = 1;
							printf("\e[1;1H\e[2J");
						}
						else if(strcmp(choix2, "2")==0) {
							stop2 = 1;
							printf("\e[1;1H\e[2J");
						}
						else{
							printf("\e[1;1H\e[2J");
							stop2 = 0;
						}
					}
					stop3 = 1;
					stop1 = 0;
				}
				else{
					printf("\e[1;1H\e[2J");
					printf("\t\tle produit dont l'identifiant est : %d nexiste pas en stock\n", id);
					printf("\n");
					printf("\t\tEntrez un identifiant valide:\n");
					stop3 = 0;
				}
			}
		}	
		else if(strcmp(choix1, "2")==0){
			printf("\e[1;1H\e[2J");
			print_stocks(prod, stocks);
			printf("\n\n");
			stop1 = 0;
		}
		else if(strcmp(choix1, "3")==0){
			printf("\e[1;1H\e[2J");
			stop1 = 1;
		}
		else{
			printf("\e[1;1H\e[2J");
			stop1 = 0;
		}
	}
}
	
//ajouter un nouveau produit dans le stock
void nouveau_prod(produit* new_prod, char* stocks){	
	produit* prod = malloc(sizeof(produit));
	stop4 = 0;
	while(stop4 != 1){
	printf("\t---------------------------------Vous etes dans le menu AJOUTER UN NOUVEAU PRODUIT---------------------------\n");
		//prix unitaire du produit
		printf("\tprix unitaire du produit:\n");
		lire(PU, 10);
		prod->prix_unit = atof(PU);
		while(atof(PU)<=0){
			printf("\e[1;1H\e[2J");
	printf("\t---------------------------------Vous etes dans le menu AJOUTER UN NOUVEAU PRODUIT---------------------------\n");
			printf("\tprix unitaire du produit:\n");
			lire(PU, 10);
			prod->prix_unit = atof(PU);
		}
		prod->prix_unit = atof(PU);
		//stock du produit
		printf("\tstock du produit:\n");
		lire(ST, 10);
		prod->stocks = atof(ST);
		while(atof(ST)<=0){
			printf("\e[1;1H\e[2J");
	printf("\t---------------------------------Vous etes dans le menu AJOUTER UN NOUVEAU PRODUIT---------------------------\n");
			printf("\tprix unitaire du produit:\n");
			printf("%.2lf\n", prod->prix_unit);
			printf("\tstock du produit:\n");
			lire(ST, 10);
			prod->stocks = atof(ST);
		}
		//nom du produit
		printf("\tnom du produit:\n");
		lire(prod->nom, 64);
		while(inalphabet(prod->nom)!=1){
			printf("\e[1;1H\e[2J");
	printf("\t---------------------------------Vous etes dans le menu AJOUTER UN NOUVEAU PRODUIT---------------------------\n");
			printf("\tprix unitaire du produit:\n");
			printf("%.2lf\n", prod->prix_unit);
			printf("\tstock du produit:\n");
			printf("%.2lf\n", prod->stocks);
			printf("\tnom du produit:\n");
			lire(prod->nom, 64);
		}
		stop1 = 0;
		while(stop1 !=1){
			printf("\t\t1-) Entrez 1 pour enregistrer\n");
			printf("\t\t2-) Entrez 2 pour annuler\n");
			printf("\t\t3-) Entrez 3 pour revenir au menu principal\n");
			lire(choix1, 10);
			//structure de controle if/else
			if (strcmp(choix1, "1") ==0){
				ajouter(prod, 1, stocks);
				printf("\e[1;1H\e[2J");
				stop2 = 0;
				while(stop2 !=1){
					printf("\t\t1-) Entrez 1 pour continuer\n");
					printf("\t\t2-) Entrez 2 pour revenir au menu principal\n");
					lire(choix2, 10);
					if (strcmp(choix2, "1") ==0){
						printf("\e[1;1H\e[2J");
						stop2 = 1;
						stop1 = 1;
						stop4 = 0;
					}
					else if (strcmp(choix2, "2") ==0){
						printf("\e[1;1H\e[2J");
						stop2 = 1;
						stop1 = 1;
						stop4 = 1;
					}
					else{
						stop2 = 0;
					}
				}
			}
			else if(strcmp(choix1, "2") ==0){
				printf("\e[1;1H\e[2J");
				stop3 = 0;
				while(stop3 !=1){
					printf("\t\t1-) Entrez 1 pour continuer\n");
					printf("\t\t2-) Entrez 2 pour revenir au menu principal\n");
					lire(choix3, 10);
					if (strcmp(choix3, "1") ==0){
						printf("\e[1;1H\e[2J");
						stop3 = 1;
						stop1 = 1;
						stop4 = 0;
					}
					else if (strcmp(choix3, "2") ==0){
						printf("\e[1;1H\e[2J");
						stop3 = 1;
						stop1 = 1;
						stop4 = 1;
					}
					else{
						stop3 = 0;
					}
				}
			}
			else if(strcmp(choix1, "3") ==0){
				printf("\e[1;1H\e[2J");
				stop1 = 1;
				stop4 = 1;
			}
			else{
				printf("\e[1;1H\e[2J");
				stop1 = 0;
	printf("\t---------------------------------Vous etes dans le menu AJOUTER UN NOUVEAU PRODUIT---------------------------\n");
				printf("\tprix unitaire du produit:\n");
				printf("%.2lf\n", prod->prix_unit);
				printf("\tstock du produit:\n");
				printf("%.2lf\n", prod->stocks);
				printf("\tnom du produit:\n");
				printf("%s\n", prod->nom);
			}
		}
	}
	free(prod);
}

//Afficher la comptabilité
size_t nb_ticket(char* chaine){
	char *p = strtok(chaine, ";");
	size_t i;
	for (i =0; p!=NULL; i++){
		p = strtok(NULL, ";");
	}
	return i-1;
}

char* copy_fich_tab(FILE* f_in){
	//trouver la taille du fichier d’entrée avec fseek et ftell
	fseek(f_in, 0 , SEEK_END);
	int a = ftell(f_in);
	//allouer un char* tampon de la bonne taille
	char* tampon = malloc(a*sizeof(char));
	//écrire le contenu dans tampon dans f_out
	rewind(f_in);
	fread(tampon, sizeof(char), a, f_in);
	return tampon;
}

void affiche_compta(char* chaine, FILE* fich){
	stop1 = 0;
	while(stop1 != 1){
	printf("\t-----------------------%ld TICKET(S) ENCAISSE(S)---------------------------\n", nb_ticket(copy_fich_tab(fich)));
		char *p = strtok(chaine, ";");
		size_t i;
		printf("\t\tdate \t\tID_client \tID_ticket \tPrix_total\n\n");
		for (i =0; p!=NULL; i++){
			printf("%s", p);
			p = strtok(NULL, ";");
		}
	printf("\t-------------------------------------------------------------------------\n");
		printf("\n\n");
		printf("\t\tTapez 1 pour revenir au menu precedent\n");
		lire(choix1, 2);
		if (strcmp(choix1, "1")==0){
			printf("\e[1;1H\e[2J");
			stop1 = 1;
		}
		else{
			printf("\e[1;1H\e[2J");
			stop1 = 0;
		}
	}
}

void tab_prod(produit* new_tab, char* stocks){
	charge_new(new_tab, stocks);
}

int MENU_GERANT(){
	FILE* fich;
	fich = fopen("compta.csv", "r");
	produit* new_prod = malloc(nb_ligne("stocks")*sizeof(produit));
	tab_prod(new_prod, "stocks");
	printf("\e[1;1H\e[2J");
	stop1 = 0;
	while(stop1 !=1){
	printf("\t---------------------------------BIENVENUE DANS LE MODE GERANT (GESTION DE STOCKS)---------------------------\n");
		printf("\t\t1-) Entrez 1 POUR AJOUTER UN NOUVEAU PRODUIT DANS LE STOCK\n");
		printf("\t\t2-) Entrez 2 POUR MODIFIER UN PRODUIT\n");
		printf("\t\t3-) Entrez 3 POUR SUPPRIMER UN PRODUIT\n");
		printf("\t\t4-) Entrez 4 POUR AFFICHER LES PRODUITS\n");
		printf("\t\t5-) Entrez 5 POUR AFFICHER LA COMPTABILITE\n");
		printf("\t\t6-) Entrez 6 POUR QUITTER CE MODE\n");
		lire(choix1, 2);
		if(strcmp(choix1, "1") ==0){
			printf("\e[1;1H\e[2J");
			nouveau_prod(new_prod, "stocks");
			stop1 = 0;
			//mettre àn jour le tableau dynamique de produits pour afficher le(s) nouveau(x) produit(s)
			new_prod = malloc(nb_ligne("stocks")*sizeof(produit));
			charge_new(new_prod, "stocks");
		}
		else if(strcmp(choix1, "2") ==0){
			printf("\e[1;1H\e[2J");
			modifier_prod(new_prod, "stocks");
			stop1 = 0;
		}
		else if(strcmp(choix1, "3") ==0){
			printf("\e[1;1H\e[2J");
			supprimer_prod(new_prod, "stocks");
			stop1 = 0;
		}
		else if(strcmp(choix1, "4") ==0){
			printf("\e[1;1H\e[2J");
			print_stocks(new_prod, "stocks");
			stop1 = 0;
		}
		else if(strcmp(choix1, "5") ==0){
			printf("\e[1;1H\e[2J");
			affiche_compta(copy_fich_tab(fich), fich);
			stop1 = 0;
		}
		else if(strcmp(choix1, "6") ==0){
			stop1 = 1;
		}
		else{
			printf("\e[1;1H\e[2J");
			stop1 = 0;
		}
	}
	free(new_prod);
	fclose(fich);
}

//fonction principal
//int main(){
	//MENU_GERANT();
//}
