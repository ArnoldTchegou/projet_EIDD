#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stddef.h>
#include<time.h>
#include"caisse.h"
#include"gerant.h"

//variables globales
char id[10];
char qte[10];

//variables de navigation entre les menus du programme
int stop1;
int stop2;
int stop3;
int stop4;

//variable de choix de menu
char choix1[2];
char choix2[2];
char choix3[2];
char choix[2];

//Constantes de date
const char * months [] = {"Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Aout", "Septembre", "Octobre", "Novembre", "Decembre"};

const char * days [] = {"Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"};

//Structure produit
typedef struct{
	char nom[64];
	double prix_unit;
	double stocks;
}produit;

/*maillon de la liste chainée pour gérer la liste de produit dans un panier................*/
typedef struct item_panier{
	int idProd;                               //identifiant du produit
	double quantite;                          //double pour les poduits vendus au poids
	struct item_panier* suiv;                //pointeur vers le produit suivant dans le panier
}item_panier;

/*type representant un pannier client sous forme de liste chainée................*/
typedef struct panier{
	struct item_panier* first;               //pointeur vers le produit en tete du panier
	struct tm* date_ticket;                   //date de passage d'un pannier en caisse
	double prix_total;                        //prix_total du panier
	int ticketid;                             //numéro de ticket (repart de zéro chaque jour)
	int clientid;                             //numéro de client	
}panier;

//fonction qui renvoie la date du ticket
struct tm* date(){
	time_t timestamp = time(NULL);
	struct tm* now = localtime(&timestamp);
	return now;
}

//fonction qui retourne le prix unitaire d'un produit du panier
double prix_produit(produit* prod, item_panier* item){
	return prod[item->idProd-1].prix_unit;	
}


//fonction qui calcul et retourne le total pour un produit du panier
double total_produit(produit* prod, item_panier* item){
	return prix_produit(prod, item)*item->quantite;
}

//fonction qui retourne le nom d'un produit du panier
char* nom_produit(produit* prod, item_panier* item){
	return prod[item->idProd-1].nom;	
}

//Initialiser un panier vide
panier* panier_init(){
	panier* panier = malloc(sizeof(panier));
	panier->first = NULL;
	panier->date_ticket = date();
	panier->clientid = 0;
	panier->ticketid = 0;
	return panier;
}

//fonction qui retourne le prix total du panier
double total_panier(panier* panier, produit* prod){
	item_panier* item = panier->first;
	double total = 0;
	while(item!=NULL){
		total = total + total_produit(prod, item);
		item = item->suiv;
	}
	return total;
}

//Ajouter un produit au panier
void add_panier(panier* panier, int* idProd, double quantite, produit* prod){
	item_panier* item = malloc(sizeof(item_panier));
	item->suiv = panier->first;
	item->idProd = *idProd;
	item->quantite = quantite;
	panier->first = item;	
	panier->prix_total = total_panier(panier, prod);
}

//Supprimer un produit en tete du panier
void panier_pop_front(panier* panier){
	item_panier* tampon = panier->first;
	panier->first = tampon->suiv;
	free(tampon);
}

//nombre de produits dans le panier
int nb_produit(panier* panier){
	item_panier* produit = panier->first;
	int nb_item=0;
	while (produit!=NULL){
		nb_item= nb_item + 1;
		produit = produit->suiv;
	}
	return nb_item;
}

//fonction qui vide le panier
void panier_free(panier* panier){
	item_panier* tampon = panier->first;
	item_panier* suiv = tampon->suiv;
	while (suiv!=NULL){
		panier->first = tampon->suiv;
		free(tampon);
		tampon = panier->first;
		suiv = tampon->suiv;
	}	
}

//fonction qui retourne l'adresse d'un produit du panier d'index index à supprimer
item_panier* panier_get_item(panier* panier, int index){
	item_panier* tampon = panier->first;
	while((tampon!=NULL)&&(index>0)){
		tampon = tampon->suiv;
		index--;
	}
	return tampon;
}

//Supprimer un produit d'index index
void panier_erase(panier* panier, int index, produit* prod){
		//si l'index est 0 on doit juste supprimer un produit en tete du panier
		if(index==0){
			panier_pop_front(panier);
			//mettre à jour le prix total du panier
			panier->prix_total = total_panier(panier, prod);
		}
		else{
			//on cherche le produit precedent l'endroit ou doit se faire la suppression
			item_panier* preced = panier_get_item(panier, index-1);
			//on fait les bons chainages
			item_panier* tampon = preced->suiv;
			preced->suiv = preced->suiv->suiv;
			free(tampon);
			//mettre à jour le prix total du panier
			panier->prix_total = total_panier(panier, prod);
		}
}

//Afficher les produits du panier
void panier_print(produit* prod, panier* panier){
	item_panier* item = panier->first;
	printf("\t-----------------------------------%d PRODUIT(S) DANS LE PANIER-------------------------------\n", nb_produit(panier));
	while(item!=NULL){
		printf("\tid %d: \t%s \t\tPrix_unitaire: %lf \tQuantite: %lf\t\ttotal: %lf\n", item->idProd, prod[item->idProd-1].nom, prod[item->idProd-1].prix_unit, item->quantite, total_produit(prod,item));
		item = item->suiv;
	}
	printf("\n");
	printf("\tPrix total de la commande: %lf\n", panier->prix_total);
}

//PARTIE CAISSIER
//pour retourner l'id du client en caisse
int client_id(){
	printf("\t--------------------------------------Bienvenue en caisse---------------------------------------\n");
	printf("\t\tAvez vous un numero client?\n");
	printf("\t\tEntrez O ou o pour OUI:\n");
	printf("\t\tEntrez N ou n pour NON:\n");
	scanf("%s", choix);
	strcpy(id, "0");
	while(atoi(id)<=0){
		if ((strcmp(choix, "O")==0)||(strcmp(choix, "o")==0)){
			printf("\e[1;1H\e[2J");
		printf("\t--------------------------------------Bienvenue en caisse---------------------------------------\n");
			printf("\t\tQuel est votre numero client?:\n");
			scanf("%s", id);
		}
		else if((strcmp(choix, "N")==0)||(strcmp(choix, "n")==0)){
			strcpy(id, "1"); //id = 1 par defaut
		}
		else{
			printf("\e[1;1H\e[2J");
		printf("\t--------------------------------------Bienvenue en caisse---------------------------------------\n");
			printf("\t\tAvez vous un numero client?\n");
			printf("\t\tEntrez O ou o pour OUI:\n");
			printf("\t\tEntrez N ou n pour NON:\n");
			scanf("%s", choix);
		}
	}
	return atoi(id);
}
//On verifie que le stock est suffisant
void verif_stocks(produit* prod, double* qte_prod, int* var, char* stocks){
	stop1 = 0;
	printf("\t-----------------------------------Gerer votre panier et payer en caisse------------------------------------\n");
	printf("\tEntrez l'identifiant du produit:\n");
	scanf("%s", id);
	while((atoi(id)<=0)||(atoi(id)>nb_ligne(stocks))){
		printf("\e[1;1H\e[2J");
	printf("\t-----------------------------------Gerer votre panier et payer en caisse------------------------------------\n");
		printf("\tEntrez l'identifiant du produit:\n");
		scanf("%s", id);
	}
	printf("\tEntrez la quantite:\n");
	scanf("%s", qte);
	while(atof(qte)<=0){
		printf("\e[1;1H\e[2J");
	printf("\t-----------------------------------Gerer votre panier et payer en caisse------------------------------------\n");
		printf("\tidentifiant du produit:\n");
		printf("%d\n", atoi(id));
		printf("\tEntrez la quantite:\n");
		scanf("%s", qte);
	}
	while(stop1!=1){
		*var = atoi(id);
		*qte_prod = atof(qte);
		if(prod[*var-1].stocks >= *qte_prod){
			printf("\e[1;1H\e[2J");
	printf("\t-----------------------------------Gerer votre panier et payer en caisse------------------------------------\n");
			printf("\n");
			printf("\t\tQuantite de la commande: %.2lf\n", *qte_prod);
			printf("\n");
			printf("\t\t%s  \t\tstocks :%.2lf\n", prod[*var-1].nom, prod[*var-1].stocks);
			printf("\n");
			stop1=1;
		}
		else{
			printf("\e[1;1H\e[2J");
	printf("\t-----------------------------------Gerer votre panier et payer en caisse------------------------------------\n");
			stop1 =0;
			printf("\n");
			printf("\tstocks insufissant: \t\t%s  \t\tstocks :%.2lf\n", prod[*var-1].nom, prod[*var-1].stocks);
			printf("\n");
			printf("\tEntrez la quantite à nouveau:\n");
			scanf("%s", qte);
		}
	}
}

//création du numéro de ticket: ticketid
//size_t recherche(char* chaine){
	//char *p = strtok(chaine, ";");
	//size_t i;
	//for (i =0; p!=NULL; i++){
		//p = strtok(NULL, ";");
	//}
	//return i;
//}

//creer un ticket et l'enregistrer dansd le fichier compta.txt
void creer_ticket(panier* panier, FILE* f, int ticketid){
	panier->ticketid = ticketid;
	struct tm* now = panier->date_ticket;
	fprintf(f, "\t%4d-%02d-%02d %02d:%02d:%02d \t\t%d \t\t%d \t%lf;\n",now->tm_year+1900, now->tm_mon+1, now->tm_mday, now->tm_hour, now->tm_min, now->tm_sec, panier->clientid, panier->ticketid, panier->prix_total);
}

//Fonction qui retourne l'index d'un produit dans le panier
int index_item(panier* panier, int idProd){
	item_panier* item = panier->first;
	int index = 0;
	while((item!=NULL)&&(item->idProd!=idProd)){
		index++;
		item = item->suiv;	
	}
	return index;
}

//Fonction qui retourne la d'un produit dans le panier
double quantite_item(panier* panier, int idProd){
	item_panier* item = panier->first;
	while((item!=NULL)&&(item->idProd!=idProd)){
		item = item->suiv;	
	}
	return item->quantite;
}

//ajouter un produit au panier et gerer les doublons dans le panier
void doublons_panier(panier* panier, produit* prod, int id, double qte_prod){
	item_panier* item = panier->first;
	while((item!=NULL)&&(item->idProd!=id)){
		item = item->suiv;
	}
	if((item!=NULL)&&(item->idProd==id)){
		item->quantite = item->quantite + qte_prod;
	}
	else{
		add_panier(panier, &id, qte_prod, prod);
	}	

}

//suppression d'un produit du panier
void supprimer_enpanier(produit* prod, char* stocks, panier* panier, int* id_sup){
	printf("\e[1;1H\e[2J");
	panier_print(prod, panier);
	printf("\n");
	printf("\tDonner l'identifiant du produit a supprimer:\n");
	scanf("%s", id);
	stop1 = 0;
	while(stop1 != 1){
		item_panier* item = panier->first;
		while((item!=NULL)&&(item->idProd!=atoi(id))){
			item = item->suiv;
		}
		if((item!=NULL)&&(item->idProd==atoi(id))){
			*id_sup = atoi(id);
			//mettre à jour le stock du produit avant la suppression
			prod[*id_sup-1].stocks = prod[*id_sup-1].stocks + quantite_item(panier, *id_sup);
			ecraser(prod, nb_ligne(stocks), stocks);
			panier_erase(panier, index_item(panier, *id_sup), prod);
			stop1 = 1;
		}
		else{
			printf("\e[1;1H\e[2J");
			panier_print(prod, panier);
			printf("\n");
			printf("\tDonner l'identifiant du produit a supprimer:\n");
			scanf("%s", id);
			stop1 = 0;
		}
	}
}

//pour ouvrir et enregistrer un produit au panier
int enregistre(produit* prod, panier* panier, char* stocks, FILE* f){
	int id;
	double qte_prod ;
	int id_sup;
	stop1 = 0;
	while(stop1!=1){
		//On verifie le stock disponible
		verif_stocks(prod, &qte_prod, &id, stocks);
		//ajouter le produit dans le pannier
		stop2 = 0;
		while(stop2!=1){
			//menu d'ajout d'un produit au panier
			printf("\t\t1-) Entrez 1 pour ajouter le produit au panier:\n");
			printf("\t\t2-) Entrez 2 pour anuler:\n");
			scanf("%s", choix1);
			if (strcmp(choix1, "1")==0){
				//ajouter un produit au panier et gerer les doublons
				doublons_panier(panier, prod, id, qte_prod);
				//mettre à jour le stock du produit
				prod[id-1].stocks = prod[id-1].stocks - qte_prod;
				ecraser(prod, nb_ligne(stocks), stocks);
				printf("\e[1;1H\e[2J");
				stop2 = 1;
				stop1 = 1;
			}
			else if(strcmp(choix1, "2")==0){
				stop2 = 1;
				printf("\e[1;1H\e[2J");
			}
			else{
				printf("\e[1;1H\e[2J");
	printf("\t-----------------------------------Gerer votre panier et payer en caisse------------------------------------\n");
				printf("\n");
				printf("\t\tQuantité de la commande: %.2lf\n", qte_prod);
				printf("\n");
				printf("\t\t%s  \t\tstocks :%.2lf\n", prod[id-1].nom, prod[id-1].stocks);
				stop2 = 0;
			}
		}
		stop4 = 0;
		while(stop4!=1){
	printf("\t-----------------------------------Gerer votre panier et payer en caisse------------------------------------\n");
			//menu d'affichage du panier en cours et de suppression d'un produit
			printf("\t\t1-) Entrez 1 pour recommencer:\n");
			printf("\t\t2-) Entrez 2 pour afficher le panier en cours:\n");
			printf("\t\t3-) Entrez 3 pour enregister le ticket et quitter:\n");
			printf("\t\t4-) Entrez 4 quitter sans enregistrer:\n");
			scanf("%s", choix2);
			if (strcmp(choix2, "1")==0){
				printf("\e[1;1H\e[2J");
				stop4 = 1;
				stop1 = 0;
			}
			else if(strcmp(choix2, "2")==0){
				printf("\e[1;1H\e[2J");
				panier_print(prod, panier);
				stop3 = 0;
				while(stop3!=1){
					printf("\n");
					printf("\t1-) Entrez 1 pour supprimer un produit:\n");
					printf("\t2-) Entrez 2 pour quitter:\n");
					scanf("%s", choix3);
					if ((strcmp(choix3, "1")==0)&&(panier->first!=NULL)){
						supprimer_enpanier(prod, stocks, panier, &id_sup);
						printf("\e[1;1H\e[2J");
					     	stop3 = 1;
					     	stop4 = 0;
					}
					else if (strcmp(choix3, "2")==0){
						printf("\e[1;1H\e[2J");
						stop3 = 1;
						stop4 = 0;
					}
					else{
						printf("\e[1;1H\e[2J");
						panier_print(prod, panier);
						stop3 = 0;
					}
				}
			}
			else if(strcmp(choix2, "3")==0){
				if (panier->first!=NULL){
					//on cree le ticket
					creer_ticket(panier, f, nb_ticket(copy_fich_tab(f)+1));
					//on vide le tampon
					free(copy_fich_tab(f));
					stop4 = 1;
					stop1 = 1;
				}
				else{
					//on ne cree pas de ticket
					printf("\e[1;1H\e[2J");
					stop4 = 1;
					stop1 = 1;
				}
			}
			else if(strcmp(choix2, "4")==0){
				//on ne cree pas de ticket
				printf("\e[1;1H\e[2J");
				stop4 = 1;
				stop1 = 1;
			}
			else{
				printf("\e[1;1H\e[2J");
				stop4 = 0;
			}
		}
	}
	return 0;
}

int MENU_CAISSE(){
	FILE* f = fopen("compta.csv", "a+");
	produit* prod = malloc(nb_ligne("stocks")*sizeof(produit));
	tab_prod(prod, "stocks");
	printf("\e[1;1H\e[2J");
	panier* panier = panier_init();
	stop1 = 0;
	while(stop1 !=1){
	printf("\t---------------------------------BIENVENUE DANS LE MODE CAISSIER---------------------------\n");
		printf("\t\t1-) Entrez 1 POUR DEMARRER UN NOUVEAU TICKET\n");
		printf("\t\t2-) Entrez 2 BASCULER EN MODE GERANT\n");
		printf("\t\t3-) Entrez 3 POUR QUITTER CE MODE\n");
		scanf("%s", choix);
		if(strcmp(choix, "1") ==0){
			printf("\e[1;1H\e[2J");
			//on demande le numéro client
			panier->clientid = client_id();
			printf("\e[1;1H\e[2J");
			enregistre(prod, panier, "stocks", f);
			//on vide le panier avant de quitter
			item_panier* item = panier->first;
			while(item!=NULL){
				panier_erase(panier, index_item(panier, item->idProd), prod);
				item = item->suiv;
			}
			stop1 = 0;
			printf("\e[1;1H\e[2J");
		}
		else if(strcmp(choix, "2") ==0){
			printf("\e[1;1H\e[2J");
			MENU_GERANT();
			//on vide le panier avant de quitter
			item_panier* item = panier->first;
			while(item!=NULL){
				panier_erase(panier, index_item(panier, item->idProd), prod);
				item = item->suiv;
			}
			stop1 = 1;
			
		}
		else if(strcmp(choix, "3") ==0){
			stop1 = 1;
		}

		else{
			printf("\e[1;1H\e[2J");
			stop1 = 0;
		}
	}
	//on ferme le fichier compta.csv
	fclose(f);
}

//int main(){
	//MENU_CAISSE();
//}






