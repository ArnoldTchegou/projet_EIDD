#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"caisse.h"
#include"gerant.h"

char choix[2];
int stop;

int main(){
	stop = 0;
	while(stop !=1){
		printf("\e[1;1H\e[2J");
	printf("\t---------------------------------------------------------------------------------------------------------\n");
	printf("\t--------------------------------------------BIENVENUE----------------------------------------------------\n");
	printf("\t---------------------------------------------------------------------------------------------------------\n");
		printf("\t\t1-) Entrez C ou c POUR PASSER EN MODE CAISSE\n");
		printf("\t\t2-) Entrez G ou g POUR PASSER EN MODE GERANT\n");
		printf("\t\t3-) Entrez Q ou q QUITTER\n");
		scanf("%s", choix);
		if((strcmp(choix, "C")==0)||(strcmp(choix, "c")==0)){
			printf("\e[1;1H\e[2J");
			MENU_CAISSE();
			stop = 0;
		}
		else if((strcmp(choix, "G")==0)||(strcmp(choix, "g")==0)){
			printf("\e[1;1H\e[2J");
			MENU_GERANT();
			stop = 0;
		}
		else if((strcmp(choix, "Q")==0)||(strcmp(choix, "q")==0)){
			printf("\e[1;1H\e[2J");
			stop = 1;
		}
		else{
			stop = 0;
		}
	}
	return EXIT_SUCCESS;
}






